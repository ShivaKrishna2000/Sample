export class Team {

    team_id?:number;
    teamName?:string;
    teamMaxBudget?:number;

    constructor()
    {
        
    }
}
