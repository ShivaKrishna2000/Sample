export class User {
    
    userid?:number;
    username?:string;
    age?:number;
    gender?:string;
    hobbies?:string;
    password?:string;

    

    constructor()
    {

    }
}
