package net.app.Team_Service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TeamServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
